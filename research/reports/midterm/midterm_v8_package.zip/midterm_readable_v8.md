# Understanding Reconstruction-Based Visual Token Compression: When and Why Does ApET Work?

**Midterm Progress Report | October 2026**

**Peng Chen (SBU ID 117702477) | CSE590-01 | chen439@cs.stonybrook.edu**

## 1. Abstract

This project asks when and why reconstruction-based visual token compression preserves a vision-language model’s answers, studying ApET [1] with LLaVA-1.5-7B [3] on GQA, MMStar and TextVQA. With a reproducible pipeline, we find that on a 30-question diagnostic set, reconstruction error does not consistently rank visual tokens by their measured effect on the answer. Because small component tests suggested that random retention could preserve some answers ApET lost, and the ApET paper does not compare against random token pruning, we added this comparison at scale. At an average budget of 64 tokens, complete ApET beats random pruning by 20.9 points on TextVQA and 2.5 on GQA, with no detectable difference on MMStar, mainly by losing fewer correct answers. Which component produces this advantage is not yet separated; an image-level failure predictor was not supported. Next, we plan to examine whether linear reconstructability matches what the language model can use after merging.

## 2. Problem Statement and Goal Recap

LLaVA-1.5 represents each image with 576 visual tokens, which dominate inference cost. ApET [1] compresses them without training: it keeps the tokens hardest to reconstruct linearly from a small basis and merges each discarded token into a similar retained one. Geometric reconstructability, however, need not coincide with preserving what the model computes downstream. The proposal asks: **RQ1:** How does reconstruction-based redundancy relate to a token’s contribution to the answer, across tasks and layers? **RQ2:** How much of ApET’s effectiveness comes from error-based selection, and how much from similarity-based merging? **RQ3:** Can the analysis support a lightweight improvement, such as an adaptive budget or a different basis?

**First-half objectives (all met):**

- Run native ApET and uncompressed LLaVA-1.5 inference in a stable, reproducible environment.

- Prepare GQA, MMStar and TextVQA evaluation subsets, baseline predictions and scoring.

- Instrument reconstruction errors, selections, merges and answer responses.

## 3. Methods and Implementation to Date

**Reproducibility.** We run the public ApET code with LLaVA-1.5-7B in FP16 on Kaggle (2×T4 GPUs), in a locked environment (Python 3.10, PyTorch 2.1.2 [7], HuggingFace Transformers 4.37.2 [8]). Our runners and scoring are separate from ApET’s code; all predictions are archived, and protocols are tracked in Git.

![Figure 1](figures/apet_pipeline_v4.png)

**Figure 1.** ApET’s two compression stages, and where RQ1 (on separate uncompressed runs) measures E and answer responses.

**Terms.** A *schedule* K1→K2 keeps K1 visual tokens after the encoder and K2 after block 16; averaged over the 32 decoder layers, 96→32 corresponds to 64 tokens and 288→96 to 192, two of the budgets in ApET’s Table 1. The *basis* is 10 tokens chosen by farthest-point sampling (FPS) in feature space; their representations are always preserved, inserted into retained token slots, though not necessarily at their original positions. *Reconstruction error* (E) measures how poorly a token is approximated by a linear combination of the basis; ApET retains the highest-E tokens. *Merging* averages each discarded token into its most cosine-similar retained token. *Random pruning* keeps the same counts at the same stages, chosen uniformly at random, with no basis, E or merging. *APR* is the share of baseline-correct answers still correct after compression; a *loss* is a correct answer turned wrong, a *gain* the reverse.

**RQ1 design.** For each of the 576 tokens, we measure its effect on the probability of the first token of the reference answer. *Zeroing* is the drop when only this token is set to zero; *retention* is the probability with only this token kept, minus that with all visual tokens removed (a one-token adaptation of [2]). Both depend on the question and target answer, and neither is ground-truth importance. **RQ2 design.** We compare uncompressed inference, complete ApET and random pruning (three seeds) at both schedules, with paired 95% bootstrap intervals over images (2,000 draws). This random comparison was added beyond the proposal: early component tests suggested random retention could keep some answers ApET lost, and ApET’s own random ablation randomizes only the basis [1]. **Planned ablations:** single-component comparisons (Sections 4.4 and 6).

## 4. Preliminary Experiments and Results

**Setup.** RQ1 uses a 30-question diagnostic set over 24 images (12 GQA, 12 MMStar, 6 TextVQA [4–6]), all answered correctly without compression. They were chosen from our own input-only ApET runs at 288 tokens to include 11 losses and 19 preserved answers, so the set is enriched for failures and is not representative. RQ2 uses 800 GQA development questions (100 images), all 1,500 MMStar questions, and 100 TextVQA development questions. Metrics: GQA and MMStar accuracy; TextVQA ten-annotator partial-credit score; APR and loss/gain counts.

### 4.1 Comparison with reported ApET results

Our GQA accuracy-retention ratios (92.4%/98.6% of uncompressed accuracy at 64/192 tokens) are close to those reported for ApET (91.9%/97.3% [1]), while our TextVQA ratios are lower (83.5%/88.9% vs. 91.1%/93.5%). Because our question subsets, prompts and scoring may differ from the paper’s, these numbers are not directly comparable to published results; our analysis relies on controlled comparisons within our own setup.

### 4.2 Finding 1 (RQ1): reconstruction error does not consistently rank measured answer sensitivity

Median correlations between E and either measure lie between −0.14 and +0.01 in every dataset, while individual questions range from −0.49 to +0.40 (Figure 2). The two measures also barely agree with each other (medians −0.03 to −0.01). Excluding padding and basis positions moves the GQA median for E versus retention to +0.09, without changing the overall picture. On six questions also measured after block 16, agreement did not consistently improve. E is question-independent here, whereas responses depend on the question, target and its no-image probability (Figure 3); the figure shows this mismatch without isolating its cause.

![Figure 2](figures/rq1_correlation_strip.png)

**Figure 2.** Per-question Spearman correlations over all 576 positions. Each dot is one question; bars are medians. No dataset shows a consistent positive relation.

![Figure 3](figures/same_image_comparison.png)

**Figure 3.** Two GQA questions share one image and an identical E map but differ in retention responses: for “Window”, a few tokens raise the target probability sharply; for “Bottom”, “B” already has probability 0.72 with no visual tokens.

### 4.3 Finding 2 (RQ2): ApET’s advantage over random pruning is task-dependent

At 96→32, ApET preserves 77% of TextVQA’s full-credit answers versus 35% for random, while gains are similar in five of six rows (e.g., 36 vs. 35.7 on GQA). Accuracy also hides changed answers: at GQA 288→96, a 1-point net drop combines 34 losses and 26 gains. Why the advantage varies by task is not established. On MMStar, the baseline (34.7%) is near the ~25% random-choice level reported for the benchmark [5] and predicts “A” on 70.6% of questions (28.6% of answers are A); this limits interpretation but does not establish why the ApET–random difference is small.

**Table 1.** Complete ApET versus random pruning. ApET’s advantage is large on TextVQA, small on GQA and undetectable on MMStar, and it comes mainly from fewer lost answers. Scores in %; random is mean ± sample SD over three seeds; CI is a paired 95% bootstrap interval over images; “Lost” counts baseline-correct answers that became wrong (TextVQA: full-credit correctness).

| Dataset (n) | Schedule (avg.)          | Uncompr. | ApET (share kept) |           Random |                ApET − random [95% CI] | Lost: ApET / rand. |
|:--------------|:-------------------------|---------:|------------------:|-----------------:|------------------------------------------:|-------------------:|
| TextVQA (100) | 96→32 (64)   |    49.70 |     41.50 (83.5%) | 20.63 ± 3.12 |         +20.87 [13.93, 29.03] |    10 / 28.7 of 44 |
| TextVQA (100) | 288→96 (192) |    49.70 |     44.20 (88.9%) | 34.77 ± 4.80 |           +9.43 [3.20, 15.43] |     7 / 16.0 of 44 |
| GQA (800)     | 96→32 (64)   |    69.00 |     63.75 (92.4%) | 61.29 ± 0.79 |            +2.46 [0.25, 4.71] |   78 / 97.3 of 552 |
| GQA (800)     | 288→96 (192) |    69.00 |     68.00 (98.6%) | 66.83 ± 0.62 | +1.17 [−0.58, 2.83] |   34 / 44.7 of 552 |
| MMStar (1500) | 96→32 (64)   |    34.73 |     33.40 (96.2%) | 33.53 ± 0.53 | −0.13 [−1.35, 1.07] |   79 / 76.0 of 521 |
| MMStar (1500) | 288→96 (192) |    34.73 |    35.00 (100.8%) | 35.20 ± 0.29 | −0.20 [−1.25, 0.85] |   36 / 39.0 of 521 |

### 4.4 Reconciling Findings 1 and 2

Finding 1 concerns individual token rankings; Finding 2 concerns the whole procedure, which differs from random pruning in selection, basis handling and merging at once. Two non-exclusive hypotheses remain open:

- **H1 (selection):** E-based selection keeps more useful tokens than random selection, e.g., by discarding easily reconstructed padding or background (Figure 3 shows low E on padding; not measured systematically). *Test:* vary only selection, with basis handling and merging fixed, on an unselected subset.

- **H2 (representation preservation):** preserved basis representations and merging keep information that random pruning drops. *Test:* merging on vs. off under matched selection; basis handling separately.

The diagnostic set cannot separate them. It is also where the impression behind our random comparison arose (with basis and merging fixed, random retention kept 23–27 of 30 answers vs. 19–21 for E-based selection), but it was selected from ApET’s own outcomes, so its 11 ApET losses are failures by construction; Table 1 corrects this impression at scale.

### 4.5 RQ3 feasibility, interpretation and validity

**RQ3 feasibility.** In an exploratory five-fold analysis on saved data, three image-level E features gave weak prediction of ApET losses (out-of-fold AUROC 0.41–0.57) and no clear Brier-score improvement over the base rate. This does not support the tested image-only adaptive budget; other policies remain possible. At 96→32, 56 of 100 GQA images had both lost and preserved questions under the same compressed input, motivating question-aware approaches.

- **Worked:** ApET clearly beats random pruning on TextVQA, mainly via fewer losses; GQA retention matches the paper.

- **Did not work:** E does not consistently rank tokens by either measured response on the diagnostic set; image-level E features did not predict failures.

- **Surprising failure modes:** merging can corrupt a word (“Brolio”→“Bottoli”; undoing one retained token’s merge restores it, unlike control restorations; one post-hoc case). Outcome-based case selection made E-ranking look worse than random (Section 4.4).

- **Goals not yet met:** component attribution (RQ2) and a supported RQ3 direction.

**Validity checks.** Target and scoring audits; full-576 identity (no-compression) controls and fixed-feature replays matched reference outputs exactly; all 90 recomputed correlations matched saved values; loss/gain counts satisfy correct = baseline − losses + gains in all 27 conditions. Limits: small, failure-enriched RQ1 set; first-token responses; two layers on six questions; development subsets (TextVQA: 100); intervals omit run-to-run variation; no timing.

## 5. Roadblocks, Risks and Mitigations

- **Integration:** changing Kaggle package defaults broke ApET/LLaVA compatibility. *Action:* locked environment with recorded fixes; resolved.

- **Run-to-run variation:** some fresh compressed runs change answers, although replays from saved features are exact. A targeted diagnostic found identical inputs, FPS selections and merge assignments, but post-merge features differing by up to 0.016. *Root-cause hypothesis:* nondeterministic FP16 accumulation in the CUDA `scatter_add_` used for merging (not yet isolated). *Action:* keep first runs as primaries; repeat critical cases.

- **Evaluation ambiguity:** the two answer measures rank tokens differently, so there is no single reference for which tokens are important. *Action:* report both measures and restrict claims to each.

- **Selection bias:** the diagnostic set was chosen from ApET’s outcomes. *Action:* restrict it to RQ1 and case studies.

**Table 2.** Risk register: rows match the roadblocks above, plus one planning risk (likelihood/impact qualitative).

| Risk | Likel./impact | Status | Contingency |
|---|---|---|---|
| Integration | Low / Med. | Green | Rebuild from the locked specification |
| Run-to-run variation | Med. / Med. | Yellow | Keep first runs as primaries; repeat critical cases |
| Evaluation ambiguity | High / High | Yellow | Restrict claims to each defined measure |
| Selection bias | Med. / High | Yellow | Use unselected subsets for component comparisons |
| Attribution unclear; no RQ3 candidate | Med. / Med. | Yellow | Report a well-controlled negative result |

## 6. Updated Plan and Milestones

- **Delta from proposal:** main comparisons ran in October, not mid-November, and the ApET-versus-random comparison was added (Section 3). Alternative bases are deprioritized: ApET’s ablation shows only small FPS-versus-random-basis differences [1]. RQ2 is now the main deliverable; RQ3 is an optional extension.

- **Likely focus (direction still being finalized):** whether *linear* reconstructability in the encoder’s feature space matches what the nonlinear language model can use. An easily reconstructed token is never reconstructed downstream; its information arrives only through a merged average. (a) For low-E tokens, how do answers change when a token is kept, merged, dropped, or replaced by its linear reconstruction from the basis (a diagnostic only)? (b) How do merged features differ from the originals (e.g., norm, after the projector), and does the averaging rule matter with selection fixed? Both reuse existing intervention tools.

- **Evaluation plan for final:** random pruning and fixed-budget ApET as baselines; 96→32 primary, 288→96 if feasible; a larger TextVQA subset if compute allows.

- **Success criteria:** *Minimum:* one controlled comparison isolating a single ApET component or operation on an unselected subset (≥100 questions, matched budgets, three seeds where random), reporting accuracy, APR, losses/gains and paired 95% intervals; reproducible negative or inconclusive results count. *Stretch:* if supported, an RQ3 modification compared with fixed-budget ApET at equal average tokens on held-out questions, aiming to improve preservation without reducing accuracy. Significance is reported, not required.

**Table 3.** Milestones.

| Target | Deliverable and completion criterion |
|---|---|
| Oct 30 | Submit report PDF and ~five-slide deck |
| Nov 6 | Choose one comparison and write its protocol (conditions, subsets, analysis) |
| Nov 13 | Implement it and validate on a small unselected pilot (identity and replay checks pass) |
| Nov 20 | Run the main comparison at 96→32 (288→96 if feasible) and analyze it |
| Nov 24 | RQ3 go/no-go; optionally a small test of one modification |
| Dec 15 (tentative) | Final presentation and report/code submission |

## 7. References

1. Q. Ma et al. ApET: Approximation-Error Guided Token Compression for Efficient VLMs. CVPR, 2026.
2. Y. Wang et al. When Token Pruning is Worse than Random: Understanding Visual Token Information in VLLMs. CVPR, 2026.
3. H. Liu et al. Improved Baselines with Visual Instruction Tuning. CVPR, 2024.
4. D. A. Hudson and C. D. Manning. GQA: A New Dataset for Real-World Visual Reasoning and Compositional Question Answering. CVPR, 2019.
5. L. Chen et al. Are We on the Right Way for Evaluating Large Vision-Language Models? 2024.
6. A. Singh et al. Towards VQA Models That Can Read. CVPR, 2019.
7. A. Paszke et al. PyTorch: An Imperative Style, High-Performance Deep Learning Library. NeurIPS, 2019.
8. T. Wolf et al. Transformers: State-of-the-Art Natural Language Processing. EMNLP: System Demonstrations, 2020.
