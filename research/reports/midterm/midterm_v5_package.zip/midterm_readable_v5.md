# Understanding Reconstruction-Based Visual Token Compression: When and Why Does ApET Work?

**Midterm Progress Report | October 2026**

**Peng Chen (SBU ID 117702477) | CSE590-01 | chen439@cs.stonybrook.edu**

## 1. Abstract

This project asks when and why reconstruction-based visual token compression preserves a vision-language model’s answers, studying ApET [1] with LLaVA-1.5-7B [3] on GQA, MMStar and TextVQA. We built a reproducible evaluation pipeline and measured how reconstruction error relates to each visual token’s effect on the answer. On a 30-question diagnostic panel, error does not consistently rank tokens by this effect (median correlations −0.14 to +0.01). Yet at an average budget of 64 tokens, complete ApET beats random pruning by 20.9 points on TextVQA and 2.5 on GQA, with no detectable difference on MMStar, mainly by losing fewer correct answers. Which component (selection, basis handling or merging) produces this is not yet separated, and an image-level failure predictor for adaptive budgets was not supported. Next, we will choose how to investigate the mechanism before deciding on any modification.

## 2. Problem Statement and Goal Recap

LLaVA-1.5 represents each image with 576 visual tokens, which dominate inference cost. ApET [1] compresses them without training: it keeps the tokens hardest to reconstruct linearly from a small basis and merges each discarded token into a similar retained one. Geometric reconstructability, however, need not coincide with preserving what the model computes downstream. The proposal asks: **RQ1:** How does reconstruction-based redundancy relate to a token’s contribution to the answer, across tasks and layers? **RQ2:** How much of ApET’s effectiveness comes from error-based selection, and how much from similarity-based merging? **RQ3:** Can the analysis support a lightweight improvement, such as an adaptive budget or a different basis?

**First-half objectives (all met):**

- Run native ApET and uncompressed LLaVA-1.5 inference in a stable, reproducible environment.

- Prepare GQA, MMStar and TextVQA cohorts, baseline predictions and scoring.

- Instrument reconstruction errors, selections, merges and answer responses.

**Status:** the planned RQ1 diagnostics are largely complete; RQ2’s whole-procedure comparisons are complete but component attribution is open; RQ3 is exploratory, and no modification has been chosen.

## 3. Methods and Implementation to Date

**Reproducibility.** We run the public ApET code with LLaVA-1.5-7B in FP16 on Kaggle (2×T4 GPUs), in a locked environment (Python 3.10, PyTorch 2.1.2 [7], HuggingFace Transformers 4.37.2 [8]). Our runners and scoring are separate from ApET’s code; all predictions are archived, and protocols are tracked in Git.

![Figure 1](figures/apet_pipeline_v4.png)

**Figure 1.** ApET’s two compression stages. RQ1 uses separate uncompressed runs, measuring E on the encoder output and answer responses on the projected tokens.

**Terms.** A *schedule* K1→K2 keeps K1 visual tokens after the encoder and K2 after block 16; averaged over the 32 decoder layers, 96→32 corresponds to 64 tokens and 288→96 to 192, two of the budgets in ApET’s Table 1. The *basis* is 10 tokens chosen by farthest-point sampling (FPS) in feature space; their representations are always preserved, inserted into retained token slots, though not necessarily at their original positions. *Reconstruction error* (E) measures how poorly a token is approximated by a linear combination of the basis; ApET retains the highest-E tokens. *Merging* averages each discarded token into its most cosine-similar retained token. *Random pruning* keeps the same counts at the same stages, chosen uniformly at random, with no basis, E or merging. *APR* is the share of baseline-correct answers still correct after compression; a *loss* is a correct answer turned wrong, a *gain* the reverse.

**RQ1 design.** For each of the 576 tokens, we measure its effect on the probability of the first token of the reference answer. *Zeroing* is the drop when only this token is set to zero; *retention* is the probability with only this token kept, minus that with all visual tokens removed (a one-token adaptation of [2]). Both depend on the question and target answer, and neither is ground-truth importance. **RQ2 design.** We compare uncompressed inference, complete ApET and random pruning (three seeds) at both schedules, with paired 95% bootstrap intervals over images (2,000 draws). **Planned ablations:** varying only the selection policy with basis handling and merging fixed, and merging on versus off under matched selection (Section 4.4).

## 4. Preliminary Experiments and Results

**Setup.** RQ1 uses a 30-question panel over 24 images (12 GQA, 12 MMStar, 6 TextVQA [4–6]), all answered correctly without compression. They were chosen from our own input-only ApET runs at 288 tokens to include 11 losses and 19 preserved answers, so the panel is enriched for failures and is not representative. RQ2 uses 800 GQA development questions (100 images), all 1,500 MMStar questions, and 100 TextVQA development questions. Metrics: GQA and MMStar accuracy; TextVQA ten-annotator partial-credit score; APR and loss/gain counts.

### 4.1 Comparison with reported ApET results

Relative to uncompressed accuracy, our ApET runs keep 92.4% and 98.6% on GQA (64 and 192 tokens), versus 91.9% and 97.3% reported [1]; on TextVQA, 83.5% and 88.9% versus 91.1% and 93.5%. Baselines also differ (GQA 69.0 vs. 61.9; TextVQA 49.7 vs. 58.2): subsets, scorers and prompts differ, so these are not matched replications, and the TextVQA gap is unexplained. Notably, our TextVQA prompt has only the image and question, while LLaVA’s reference launcher uses an OCR-annotated question file we could not obtain.

### 4.2 Finding 1 (RQ1): reconstruction error does not consistently rank measured answer sensitivity

Median correlations between E and either measure lie between −0.14 and +0.01 in every dataset, while individual questions range from −0.49 to +0.40 (Figure 2). The two measures also barely agree with each other (medians −0.03 to −0.01). Excluding padding and basis positions moves the GQA median for E versus retention to +0.09, without changing the overall picture. On six questions also measured after block 16, agreement did not consistently improve. E is question-independent here, whereas responses depend on the question, target and its no-image probability (Figure 3); the figure shows this mismatch without isolating its cause.

![Figure 2](figures/rq1_correlation_strip.png)

**Figure 2.** Per-question Spearman correlations over all 576 positions. Each dot is one question; bars are medians. No dataset shows a consistent positive relation.

![Figure 3](figures/same_image_comparison.png)

**Figure 3.** Two GQA questions about one image share an identical E map but produce different retention responses. For “Window”, a few tokens raise the target probability sharply; for “Bottom”, the first piece “B” already has probability 0.72 with no visual tokens.

### 4.3 Finding 2 (RQ2): ApET’s advantage over random pruning is task-dependent

**Table 1.** Complete ApET versus random pruning. ApET’s advantage is large on TextVQA, small on GQA and undetectable on MMStar, and it comes mainly from fewer lost answers. Scores in %; random is mean ± sample SD over three seeds; CI is a paired 95% bootstrap interval over images; “Lost” counts baseline-correct answers that became wrong (TextVQA: full-credit correctness).

| Dataset (n) | Schedule (avg.)          | Uncompr. | ApET (share kept) |           Random |                ApET − random [95% CI] | Lost: ApET / rand. |
|:--------------|:-------------------------|---------:|------------------:|-----------------:|------------------------------------------:|-------------------:|
| TextVQA (100) | 96→32 (64)   |    49.70 |     41.50 (83.5%) | 20.63 ± 3.12 |         +20.87 [13.93, 29.03] |    10 / 28.7 of 44 |
| TextVQA (100) | 288→96 (192) |    49.70 |     44.20 (88.9%) | 34.77 ± 4.80 |           +9.43 [3.20, 15.43] |     7 / 16.0 of 44 |
| GQA (800)     | 96→32 (64)   |    69.00 |     63.75 (92.4%) | 61.29 ± 0.79 |            +2.46 [0.25, 4.71] |   78 / 97.3 of 552 |
| GQA (800)     | 288→96 (192) |    69.00 |     68.00 (98.6%) | 66.83 ± 0.62 | +1.17 [−0.58, 2.83] |   34 / 44.7 of 552 |
| MMStar (1500) | 96→32 (64)   |    34.73 |     33.40 (96.2%) | 33.53 ± 0.53 | −0.13 [−1.35, 1.07] |   79 / 76.0 of 521 |
| MMStar (1500) | 288→96 (192) |    34.73 |    35.00 (100.8%) | 35.20 ± 0.29 | −0.20 [−1.25, 0.85] |   36 / 39.0 of 521 |

At 96→32, ApET preserves 77% of TextVQA’s full-credit answers versus 35% for random, while gains are similar in five of six rows (e.g., 36 vs. 35.7 on GQA). Accuracy also hides changed answers: at GQA 288→96, a 1-point net drop combines 34 losses and 26 gains. Why the advantage varies by task is not established. On MMStar, the baseline (34.7%) is near the ~27% chance level and predicts “A” on 70.6% of questions (28.6% of answers are A), which may limit any method’s effect (untested).

### 4.4 Reconciling Findings 1 and 2

Finding 1 concerns individual token rankings; Finding 2 concerns the whole procedure, which differs from random pruning in selection, basis handling and merging at once. Two non-exclusive hypotheses remain open:

- **H1 (selection):** E-based selection keeps more useful tokens than random selection, e.g., by discarding easily reconstructed padding or background (Figure 3 shows low E on padding; not measured systematically). *Test:* vary only selection, with basis handling and merging fixed, on an unselected cohort.

- **H2 (representation preservation):** preserved basis representations and merging keep information that random pruning drops. *Test:* merging on vs. off under matched selection; basis handling separately.

The existing panel cannot separate them: with basis and merging fixed, random retention preserved 23–27 of 30 answers versus 19–21 for E-based selection, but the panel was selected from ApET’s own outcomes in this setting, so its 11 ApET losses are failures by construction.

### 4.5 First RQ3 feasibility check

A fixed three-feature model of image-level E statistics, evaluated with five image-grouped folds on saved data, gave out-of-fold AUROCs of 0.41–0.57 for predicting ApET losses and no clear Brier-score improvement over the base rate on any dataset. This is insufficient evidence that the tested features predict failures reliably, so we have not selected this approach; question-aware or other adaptive policies remain possible. Notably, at 96→32, 56 of 100 GQA images had both lost and preserved questions under the same compressed input.

### 4.6 Interpretation and validity

- **Worked:** ApET clearly beats random pruning on TextVQA (+20.9 points at 64 tokens), mainly via fewer losses; our GQA retention matches the paper’s.

- **Did not work:** E does not rank tokens by measured answer sensitivity, and image-level E features did not predict failures.

- **Surprising failure modes:** merging can corrupt a word: ApET turns “Brolio” into “Bottoli”, and undoing one retained token’s merge restores it, unlike control restorations (one post-hoc case). Also, selecting cases by ApET’s outcomes made E-ranking look worse than random, an artifact we now avoid.

- **Goals not yet met:** component attribution (RQ2) and a supported RQ3 direction.

**Validity checks.** Target and scoring audits; no-op compression checks; exact replays from saved features; recomputing all 90 saved correlations reproduced them to 10⁻¹⁶; loss/gain counts satisfy correct = baseline − losses + gains in all 27 conditions. Limits: small failure-enriched RQ1 panel; first-token responses; two layers on six questions; development subsets (TextVQA: 100); intervals omit run-to-run variation; no speed claims.

## 5. Roadblocks, Risks and Mitigations

- **Integration:** changing Kaggle package defaults broke ApET/LLaVA compatibility. *Action:* locked environment with recorded fixes. *Status:* resolved (Green).

- **Run-to-run variation:** some fresh compressed runs change answers, although replays from saved features are exact. *Root cause:* unidentified; we suspect nondeterministic FP16 GPU numerics (untested). *Action:* keep first runs as primaries; log changes; repeat decisive cases.

- **Evaluation ambiguity:** answer measures disagree; reference TextVQA prompt file unavailable. *Action:* report both measures; compare only relative retention with the paper.

- **Selection bias:** outcome-selected diagnostic cases. *Action:* panel limited to RQ1 and case studies; component comparisons on unselected cohorts.

**Table 2.** Risk register (likelihood and impact are qualitative).

| Risk | Likel./impact | Status | Contingency |
|---|---|---|---|
| Answer measures disagree | High / High | Yellow | Restrict claims to each defined measure |
| Selection bias in diagnostic panels | High / High | Yellow | Use unselected cohorts for component comparisons |
| Fresh-run variation | Med. / Med. | Yellow | Repeat cases that conclusions depend on |
| Attribution stays unclear; no RQ3 candidate | Med. / Med. | Yellow | Report a well-controlled negative result |

## 6. Updated Plan and Milestones

- **Delta from proposal:** the proposal placed main analysis in early–mid November; the main comparisons ran in October, but attribution needs more work than a correlation study suggested. The next direction is therefore chosen first (after more analysis, informed by our ongoing study of how ApET’s reconstruction and merging interact with attention), and RQ3 is conditional on it.

- **Candidate directions (none committed):** H1/H2 tests on unselected cohorts (Section 4.4); which question types ApET loses; how often merge-induced failures occur.

- **Evaluation plan for final:** pure random pruning and fixed-budget ApET as baselines, plus component-controlled variants if attribution is pursued; matched token counts at both schedules, three seeds, paired intervals, APR and losses/gains; held-out GQA questions for any RQ3 method; controlled timing only if efficiency is claimed.

- **Success criteria:** a component is credited with part of ApET’s advantage only if its paired 95% interval against complete ApET excludes zero at both schedules; an RQ3 modification is accepted only if it reduces lost answers versus fixed-budget ApET at equal average tokens, with a paired 95% interval excluding zero on held-out GQA. A documented negative result is acceptable.

**Table 3.** Milestones.

| Target | Deliverable and completion criterion |
|---|---|
| Oct 30 | Submit report PDF and ~five-slide deck |
| Nov 6 | Choose the direction and method; record the rationale, or why existing evidence is insufficient |
| Nov 13 | Run the chosen comparison, if feasible, with conditions and analysis fixed in writing beforehand |
| Nov 20 | RQ3 go/no-go: justify one modification, or document why none is supported |
| Dec 15 (tentative) | Final presentation and report/code submission |

## 7. References

1. Q. Ma et al. ApET: Approximation-Error Guided Token Compression for Efficient VLMs. CVPR, 2026.
2. Y. Wang et al. When Token Pruning is Worse than Random: Understanding Visual Token Information in VLLMs. CVPR, 2026.
3. H. Liu et al. Improved Baselines with Visual Instruction Tuning. CVPR, 2024.
4. D. A. Hudson and C. D. Manning. GQA: A New Dataset for Real-World Visual Reasoning and Compositional Question Answering. CVPR, 2019.
5. L. Chen et al. Are We on the Right Way for Evaluating Large Vision-Language Models? 2024.
6. A. Singh et al. Towards VQA Models That Can Read. CVPR, 2019.
7. A. Paszke et al. PyTorch: An Imperative Style, High-Performance Deep Learning Library. NeurIPS, 2019.
8. T. Wolf et al. Transformers: State-of-the-Art Natural Language Processing. EMNLP: System Demonstrations, 2020.
